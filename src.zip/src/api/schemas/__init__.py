from .PredictRequest import PredictRequest
from .PredictResponse import PredictResponse

__all__ = [
    "PredictRequest",
    "PredictResponse",
]
